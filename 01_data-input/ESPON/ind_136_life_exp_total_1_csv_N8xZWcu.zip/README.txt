# ESPON package for the indicator 'life_exp_total_&lt;1'

This readme file describes the content of this Indicator package.


## Information

- Name: Life expectancy - age group 1 year
- Code: life_exp_total_&lt;1
- Id: 136


### Abstract

Total population Life expectancy by age by NUTS 2, age group 1 years 


## File(s)

- README.txt: This file
- ind_136_life_exp_total_1_data.csv: Data file
- ind_136_life_exp_total_1_data.xls: Data file
- ind_136_life_exp_total_1_metadata_inspire.xml: Metadata Inspire
- ind_136_life_exp_total_1_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

