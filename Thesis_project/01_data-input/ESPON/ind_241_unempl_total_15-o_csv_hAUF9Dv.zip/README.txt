# ESPON package for the indicator 'unempl_total_15-O'

This readme file describes the content of this Indicator package.


## Information

- Name: Unemployment (total) - age group 15+
- Code: unempl_total_15-O
- Id: 241


### Abstract

Unemployment population represents those persons who are either without work during the reference week currently available for work, actively seeking work or who had found a job to start within a period of at most three months.


## File(s)

- README.txt: This file
- ind_241_unempl_total_15-o_data.csv: Data file
- ind_241_unempl_total_15-o_data.xlsx: Data file
- None: Metadata Inspire
- ind_241_unempl_total_15-o_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

