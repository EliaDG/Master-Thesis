# ESPON package for the indicator '25-64_T_5-8'

This readme file describes the content of this Indicator package.


## Information

- Name: Population - age group 25-64 - with educational attainment level 5-8 (%)
- Code: 25-64_T_5-8
- Id: 299


### Abstract

Educational attainment levels are usually presented for three main categories: Less than primary, primary and lower secondary education (ISCED 2011 levels 0-2). Upper secondary and post-secondary non-tertiary education (ISCED 2011 levels 3 and 4). Tertiary education (ISCED 2011 levels 5-8)


## File(s)

- README.txt: This file
- ind_299_25-64_t_5-8_data.csv: Data file
- ind_299_25-64_t_5-8_data.xlsx: Data file
- None: Metadata Inspire
- ind_299_25-64_t_5-8_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

